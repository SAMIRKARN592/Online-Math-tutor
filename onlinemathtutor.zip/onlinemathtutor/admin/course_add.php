<?php
                           include '../connection.php'; 
                                $title=$_POST['title'];

                                    $sql=  "INSERT INTO courses(course_name) VALUES ( '$title')";
                                    $result= mysqli_query($connection,$sql);
                                    echo "<script>alert('new course added')</script>";

                                    if (isset($result)) {

                        header('Location: courses.php');
                                }
                                

                                ?>