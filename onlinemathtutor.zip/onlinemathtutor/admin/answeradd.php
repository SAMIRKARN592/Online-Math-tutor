 <?php
                            include "../connection.php";
                                $ans= $_POST['ans'];
                               
                                $ques=$_POST['ques'];
                                $status=$_POST['status'];
                                
                                $sql5 = "INSERT INTO answer(answ,Questions_id,correct) VALUES ('$ans',$ques','$status');";
                                $res=mysqli_query($connection,$sql5);
                                if (isset($res)) {
                                	# code..
                                	echo"<script>alert('Answer added')</script>";
                                	header('Location: questions.php');
                                }
                            
                            ?>