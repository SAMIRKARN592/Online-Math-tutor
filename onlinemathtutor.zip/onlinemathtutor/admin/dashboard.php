

 <?php
 session_start();
include'../connection.php';
 if (!isset($_SESSION['adminlogin'])) {
        header('Location: ../login.php');
    }
?>
<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Admin dashboard</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />
    <!-- CSS Files -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/light-bootstrap-dashboard.css?v=2.0.0 " rel="stylesheet" />
    <!-- CSS Just for demo purpose, don't include it in your project -->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

    <style type="text/css">
.contain {
    max-width: 1100px;
    margin: 0 auto;
    overflow: auto;
}
.conta{
        background:#9bfd87;
        border-radius: 50%;   
}

header {
    flex: 1;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}

header h1 {
    font-size: 60px;
}

.counters {
  
    padding: 40px 20px;
}

.counters .contain {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    grid-gap: 30px;
    text-align: center;
}

.counters i {
    
    margin-bottom: 5px;
}

.counters .counter {
    font-size: 45px;
    margin: 10px 0;
}

@media (max-width: 700px) {
    .counters .container {
        grid-template-columns: repeat(2, 1fr);
    }

    .counters .container > div:nth-of-type(1),
    .counters .container > div:nth-of-type(2) {
        border-bottom: 1px lightskyblue solid;
        padding-bottom: 20px;
    }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="sidebar" data-color="green" data-image="assets/img/sidebar-3.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

        Tip 2: you can also add an image using data-image tag
    -->
            <div class="sidebar-wrapper">
                <div class="logo">
                    <a href="http://samirkarn.com.np" class="simple-text">
                        Karn Math Tutors
                    </a>
                </div>
                <ul class="nav">
                    <li class="nav-item active">
                        <a class="nav-link" href="dashboard.php">
                            <i class="nc-icon nc-chart-pie-35"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="user.php">
                            <i class="nc-icon nc-circle-09"></i>
                            <p>User Profile</p>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="table.php">
                            <i class="nc-icon nc-notes"></i>
                            <p>Tables List</p>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="Courses.php">
                            <i class="nc-icon nc-paper-2"></i>
                            <p>Courses</p>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="book_videos.php">
                            <i class="nc-icon nc-atom"></i>
                            <p>Books/Videos</p>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="questions.php">
                            <i class="nc-icon nc-pin-3"></i>
                            <p>Questions</p>
                        </a>
                    </li>
                    <li>
                        <a class="nav-link" href="reviews.php">
                            <i class="nc-icon nc-bell-55"></i>
                            <p>Reviews</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg " color-on-scroll="500">
                <div class="container-fluid">
                    <a class="navbar-brand" href="dashboard.php"> Dashboard </a>
                    <button href="" class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                        <span class="navbar-toggler-bar burger-lines"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-end" id="navigation">
                        <ul class="nav navbar-nav mr-auto">
                            <li class="nav-item">
                                <a href="#" class="nav-link" data-toggle="dropdown">
                                    <i class="nc-icon nc-palette"></i>
                                    <span class="d-lg-none">Dashboard</span>
                                </a>
                            </li>
                           
                        </ul>
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item">
                          <?php  if (isset($_SESSION['adminlogin'])) {?>
                                 <a class="nav-link" href="#"> <span class="no-icon"><?php echo $_SESSION['username'];?></span></a>
                            <?php    }  ?>      
                          
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="../component/logout.php">
                                    <span class="no-icon">Log out</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- End Navbar -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card ">
                                <div class="card-header ">
                                    <h4 class="card-title">Registered user</h4>
                                    <p class="card-category">Last registered users</p>
                                </div>
                                <div class="card-body"  style="background-color: #edf4eb;">
                                    <div id="chartPreferences" class="ct-chart ct-perfect-fourth">
                                        <?php
                                        $sql="SELECT * FROM USER WHERE Role != 1";
                                        $resu=mysqli_query($connection,$sql);
                                        while($row=mysqli_fetch_array($resu)){?>
                                                 <ul class="list-group list-group-flush">
                                              <li class="list-group-item "><i class="fa fa-user" aria-hidden="true"></i><?php print_r($row['Name'])?>
                                               <br> <i class="fa fa-envelope" aria-hidden="true"></i><?php print_r($row['email'])?></li>
                                             

                                                    </ul> 
                                        <?php }?>
                                    </div>
                                   
                                    <hr>
                                    <div class="stats">
                                        <i class="fa fa-clock-o"></i> Updates Everyday
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-8">
                            <div class="card ">
                                <div class="card-header ">
                                    <h4 class="card-title text-center">Website contents</h4>
                                    
                                </div>
                                <div class="card-body" style="background-color: #edf4eb;">
                                    <section class="counters">
            
                
                    <div class="contain">
                        <div class="conta">
                            <?php
                            $sql2="SELECT   * FROM COURSES";
                            $result= mysqli_query($connection,$sql2);
                            $count=mysqli_num_rows( $result);?>
                    <div class="counter" data-target="<?php echo $count;?>">0</div>
                    <h5>Courses</h5>
                    </div>
                <div class="conta">
                     <?php
                            $sql3="SELECT   * FROM Video";
                            $result1= mysqli_query($connection,$sql3);
                            $count1=mysqli_num_rows( $result1);?>
                    <div class="counter" data-target="<?php echo $count1;?>">0</div>
                    <h5>Total Video Tutorial</h5>
                </div>
                <div class="conta">
                    <?php
                            $sql4="SELECT   * FROM Test";
                            $result2= mysqli_query($connection,$sql4);
                            $count2=mysqli_num_rows( $result2);?>
                    <div class="counter" data-target="<?php echo $count2;?>">0</div>
                    <h5>Total Test taken</h5>
                </div>
                <div class="conta">
                     <?php
                            $sql5="SELECT   * FROM questions GROUP BY video_id";
                            $result3= mysqli_query($connection,$sql5);
                            $count3=mysqli_num_rows( $result3);?>
                    <div class="counter" data-target="<?php echo $count3;?>">0</div>
                    <h5>Total Quiz questions per video</h5>
                </div>
                </div>
            
        </section>
                                </div>
                               
                                         
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card ">
                                <div class="card-header ">
                                    <h4 class="card-title">Average video Ratings</h4>
                                    
                                </div>
                                
                                <div class="card-body"  style="background-color: #edf4eb;" >
                                    <table class="table table-hover table-striped">
                                                    <thead>
                                                        <th>Video Name</th>
                                                        <th>Rating</th>
                                                    </thead>
                                                    <tbody>
                                 <?php 
                                            $sel="SELECT * FROM VIDEO";
                                            $query=mysqli_query($connection,$sel);
                                            while ($row1=mysqli_fetch_array($query)) {
                                                
                                            

                                                $avg="SELECT AVG(Total_rating) FROM  rating where Video_id=".$row1['video_id'];
                                                $qry=mysqli_query($connection,$avg);
                                                while ( $average=mysqli_fetch_array($qry)) {
                                                    # code...
                                                
                                                
                                                
                                                ?>
                                                   
                                                    <tr>
                                                        <td><?php echo  $row1['video_title'];?></td>
                                                        <td><?php echo $average['AVG(Total_rating)'];?>
                                                      </td>
                                                    </tr>
                                                                                       
                                      
                                      <?php
                                  }
                              }
                                      ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card  card-tasks">
                                <div class="card-header ">
                                    <h4 class="card-title">Reviews</h4>
                                    <p class="card-category">Recent Reviews</p>
                                </div>
                                <div class="card-body" >
                                    <div class="table-full-width" style="background-color: #edf4eb;">
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <?php
                                                    $sql5 ="SELECT * FROM REVIEWS";
                                                    $resul=mysqli_query($connection,$sql5);
                                                    while($row5=mysqli_fetch_array($resul)){?>
                                                    <td><?php echo $row5['Description'] ;?></td>
                                                    <td class="td-actions text-right">
                                                        
                                                        
                                                       <a href="../deletereviews.php?id='<?php echo $row5["Reviews_id"];?>'"> <button type="button" rel="tooltip" title="Remove" class="btn btn-danger btn-simple btn-link">
                                                            <i class="fa fa-times"></i>
                                                        </button></a>
                                                    </td>

                                                </tr>
                                                <?php    }  
                                                ?>
                                               
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                 
                        <p class="copyright text-center">
                            ©
                            <script>
                                document.write(new Date().getFullYear())
                            </script>
                            <a href="http://www.samirkarn.com.np">Karn Math Tutors</a>
                        </p>
                    </nav>
                </div>
            </footer>
        </div>
    </div>
    <!--   -->
    <!-- <div class="fixed-plugin">
    <div class="dropdown show-dropdown">
        <a href="#" data-toggle="dropdown">
            <i class="fa fa-cog fa-2x"> </i>
        </a>

        <ul class="dropdown-menu">
			<li class="header-title"> Sidebar Style</li>
            <li class="adjustments-line">
                <a href="javascript:void(0)" class="switch-trigger">
                    <p>Background Image</p>
                    <label class="switch">
                        <input type="checkbox" data-toggle="switch" checked="" data-on-color="primary" data-off-color="primary"><span class="toggle"></span>
                    </label>
                    <div class="clearfix"></div>
                </a>
            </li>
            <li class="adjustments-line">
                <a href="javascript:void(0)" class="switch-trigger background-color">
                    <p>Filters</p>
                    <div class="pull-right">
                        <span class="badge filter badge-black" data-color="black"></span>
                        <span class="badge filter badge-azure" data-color="azure"></span>
                        <span class="badge filter badge-green" data-color="green"></span>
                        <span class="badge filter badge-orange" data-color="orange"></span>
                        <span class="badge filter badge-red" data-color="red"></span>
                        <span class="badge filter badge-purple active" data-color="purple"></span>
                    </div>
                    <div class="clearfix"></div>
                </a>
            </li>
            <li class="header-title">Sidebar Images</li>

            <li class="active">
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="../assets/img/sidebar-1.jpg" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="../assets/img/sidebar-3.jpg" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="..//assets/img/sidebar-4.jpg" alt="" />
                </a>
            </li>
            <li>
                <a class="img-holder switch-trigger" href="javascript:void(0)">
                    <img src="../assets/img/sidebar-5.jpg" alt="" />
                </a>
            </li>

            <li class="button-container">
                <div class="">
                    <a href="http://www.creative-tim.com/product/light-bootstrap-dashboard" target="_blank" class="btn btn-info btn-block btn-fill">Download, it's free!</a>
                </div>
            </li>

            <li class="header-title pro-title text-center">Want more components?</li>

            <li class="button-container">
                <div class="">
                    <a href="http://www.creative-tim.com/product/light-bootstrap-dashboard-pro" target="_blank" class="btn btn-warning btn-block btn-fill">Get The PRO Version!</a>
                </div>
            </li>

            <li class="header-title" id="sharrreTitle">Thank you for sharing!</li>

            <li class="button-container">
				<button id="twitter" class="btn btn-social btn-outline btn-twitter btn-round sharrre"><i class="fa fa-twitter"></i> · 256</button>
                <button id="facebook" class="btn btn-social btn-outline btn-facebook btn-round sharrre"><i class="fa fa-facebook-square"></i> · 426</button>
            </li>
        </ul>
    </div>
</div>
 -->
</body>
<!--   Core JS Files   -->
<script src="assets/js/core/jquery.3.2.1.min.js" type="text/javascript"></script>
<script src="assets/js/core/popper.min.js" type="text/javascript"></script>
<script src="assets/js/core/bootstrap.min.js" type="text/javascript"></script>
<!--  Plugin for Switches, full documentation here: http://www.jque.re/plugins/version3/bootstrap.switch/ -->
<script src="assets/js/plugins/bootstrap-switch.js"></script>
<!--  Google Maps Plugin    -->
<!--  Chartist Plugin  -->
<script src="assets/js/plugins/chartist.min.js"></script>
<!--  Notifications Plugin    -->
<script src="assets/js/plugins/bootstrap-notify.js"></script>
<!-- Control Center for Light Bootstrap Dashboard: scripts for the example pages etc -->
<script src="assets/js/light-bootstrap-dashboard.js?v=2.0.0 " type="text/javascript"></script>
<!-- Light Bootstrap Dashboard DEMO methods, don't include it in your project! -->
<script type="text/javascript">
    $(document).ready(function() {
        // Javascript method's body can be found in assets/js/demos.js
        demo.initDashboardPageCharts();

        demo.showNotification();

    });
</script>


</html>
<script type="text/javascript">
    const counters = document.querySelectorAll('.counter');
const speed = 10; // The lower the slower

counters.forEach(counter => {
    const updateCount = () => {
        const target = +counter.getAttribute('data-target');
        const count = +counter.innerText;

        // Lower inc to slow and higher to slow
        const inc = target / speed;

        // console.log(inc);
        // console.log(count);

        // Check if target is reached
        if (count < target) {
            // Add inc to count and output in counter
            counter.innerText = count + inc;
            // Call function every ms
            setTimeout(updateCount, 1);
        } else {
            counter.innerText = target;
        }
    };

    updateCount();
});

</script>
