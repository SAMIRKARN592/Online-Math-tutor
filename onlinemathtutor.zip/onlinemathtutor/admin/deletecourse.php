<?php
session_start();
    if (!isset($_SESSION['adminlogin'])) {
        header('Location: ../login.php');
    }
include ('../connection.php');
$id = $_GET['id'];
$sql = "DELETE FROM courses WHERE course_id = ".$id."";
$qry=mysqli_query($connection, $sql);
if (mysqli_affected_rows($connection) > 0) {
      header("Location: {$_SERVER['HTTP_REFERER']}");
} else {
      echo "Error in query: $qry. " . mysqli_error($connection);
      exit ;
}	
?>