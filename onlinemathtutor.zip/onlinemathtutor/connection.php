<?php
     $host = "localhost";
     $user = "root";
     $pass = "";
     $db = "tutor";

     $connection = mysqli_connect($host, $user, $pass, $db);
     if($connection){
     }else{
     	echo "Something Wrong!! connection Failed";
     }
     ?>