<?php
session_start();
if (isset($_SESSION['adminlogin'])) {
    header('Location: admin/dashboard.php');
}elseif (isset($_SESSION['userlogin'])) {
    header('Location: index.php');
}
include "connection.php";
if(isset($_POST['username']) && isset($_POST['pass']))
{
	function validate($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	$username = validate($_POST['username']);
	$pass = validate($_POST['pass']);
	$passwd = md5($pass);
	

if (empty($username)) {

	header("Location: login.php?error=username is required");
	exit();
	# code...
}
elseif (empty($pass)) {
header("Location: login.php?error=password is required");
	exit();
	# code...
}
else{
	$sql ="select * from user where username='$username' and password='$passwd' and Role=0 and Status=1";
	$sql2 ="select * from user where username='$username' and password='$passwd' and Role=1 and Status=1";

		$result = mysqli_query($connection,$sql);

		$result2 = mysqli_query($connection,$sql2);
		if (mysqli_num_rows($result) ) {

	 		$row =mysqli_fetch_assoc($result);
	 		if ($row['username'] === $username &&$row['password'] === $passwd ) {
	 			$_SESSION['userlogin'] =md5('123456');
	 			$_SESSION['username'] =$row['username'];
	 			$_SESSION['name']=$row['Name'];
	 			$_SESSION['id']=$row['User_id'];
	 			header("Location: video.php");
	 			exit();
 			# code...
	 		}
	 	} 
	 	elseif (mysqli_num_rows($result2) === 1) {
			
	 		$row1 =mysqli_fetch_assoc($result2);
	 		if ($row1['username'] === $username &&$row1['password'] === $passwd ) {
	 			$_SESSION['adminlogin'] =md5('123456');
	 			$_SESSION['username'] =$row1['username'];
	 			$_SESSION['name']=$row1['Name'];
	 			$_SESSION['id']=$row1['User_id'];
	 			header("Location: admin/dashboard.php");
	 			exit();	 			# code...
	 		}# code...
	 	}
		else
		{
				header("Location: login.php?error=incorrect username or password");
	exit();
		}

	}


}
else{
	header("Location: login.php");
	exit();	
}

?>