<?php
session_start();

// ob_start();
include 'connection.php';
$output="";
?>
<!DOCTYPE html>
<html>
<head>
	<title>SEARCH RESULT</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
     
</head>
<body>
	<?php
 include 'navbar.php';
 ?>


   
  <div class="container-fluid">
    <?php
    if (isset($_POST['search'])) {
  $search=$_POST['search'];
 
  $query="SELECT * FROM COURSES WHERE course_name LIKE '%$search%'";
  $result=mysqli_query($connection,$query);


  $count=mysqli_num_rows($result);
  if ($count==0) {
    echo " <h3>Your search -".$search. "</h3><br><h4>did not match any courses.Try different keywords.</h4>";
  }
  else{
    while ($row=mysqli_fetch_array($result)) {
        $course=$row['course_name'];
        
        ?>
           <div class="row">
                        <div class="col-md-12">
                            <div class="card strpied-tabled-with-hover">
                                <div class="card-header ">
                                    <h3 class="card-title text-center">YOUR SEARCHES</h3>
                                    
                                </div>
                                <div class="card-body table-full-width table-responsive">
                                    <table class="table table-hover table-striped">
                                        <thead>
                                            
                                            <th>Name of the video</th>
                                              <th>Course name</th>
                                            <th>Action</th>
                                            
                                        </thead>
                                        <tbody>

                                            <tr>
                                               <?php
                                                 $sql="SELECT * FROM VIDEO WHERE course_id =".$row['course_id'];
                                                 $result=mysqli_query($connection,$sql);


                                                     while($row1=mysqli_fetch_array($result)){?>
                                                         
                                                         
                                                   
                                                <td><?php  print_r($row1['video_title']); ?></td>
                                              
                                                <td><?php echo $course?></td>
                                                
                                                <td>  
                   <a href=" video_description.php?id=<?php echo $row1['video_id'];?> "><input type="submit" class="btn btn-primary"  value="View video"></a> 
                   <br>
                   

                                                     

                                                        
</td>        
                                                

                                            </tr>
                                           <?php 
                                           }
                                            ?>
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                 
                    </div>

 <?php   }

  }
    }
?>



 </div>

  
<!-- Footer -->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ef182329e5f694422911cce/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>