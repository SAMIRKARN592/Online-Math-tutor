<?php
session_start();
// ob_start();
include 'connection.php';
 
?>
<!DOCTYPE html>
<html>
<head>
	<title>VIDEO TUTORIALS</title>
  <link rel="icon" href="https://img.icons8.com/color/48/000000/movies-folder.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">


</head>
<body>
	<?php
 include 'navbar.php';
 ?>

<div class="row my-2">
   <div class="col-md-9"></div>
   <div class="col-md-3">
      <form method="POST" action="">
            
            <select name="sorting" style="padding-right:30px; height: 30px; width: 50%; border-bottom: 1px solid #989797; border-radius: 10px;"  id="usersort" onchange='this.form.submit()'>
                
                <?php
                $sql="SELECT * FROM COURSES";
                $query=mysqli_query($connection,$sql);
                ?>
                <option disabled="disabled" style="background: white;color: red;" selected="selected">
                   SORT BY  COURSES
                </option>
                  <?php while ($row3=mysqli_fetch_array($query)) {
                 ?> 
                 
                <option  value="<?php echo $row3['course_id'];?>">
                    <?php echo $row3['course_name'];?>
                </option>
          <?php       }
                 ?>
            </select>
        </form>

   </div> 
  </div>
   
  <div class="container-fluid">
                     <?php   if (isset($_POST['sorting'])) {
                $optional = $_POST['sorting'];?>
                 <div class="container">
                    <div class="row text-center" >
                     <?php
                                                 $sql="SELECT * FROM VIDEO WHERE course_id=$optional";
                                                 $result=mysqli_query($connection,$sql);


                                                     while($row1=mysqli_fetch_array($result)){
                                                         
                                                         
                                                    $sql2="SELECT * FROM courses WHERE course_id=".$row1['course_id']."";
                                                    $result2=mysqli_query($connection,$sql2);
                                                      while ($row2=mysqli_fetch_array($result2)) { ?>
                                                        <div class="col-md-4 " style="margin-bottom: 20px;">
                                                          <div class="card h-100">
                                                            
                                                              
                                                           
                                                            <div class="card-body">
                                                              <img src="admin/image/<?php echo $row1['Thumbnail'];?>" width="200px;" class="img-thumbnail" height="100px;">
                                                              <h5 class="text-center"><?php  print_r($row1['video_title']); ?><br></h5>
                                                <?php 
                                                $avg="SELECT AVG(Total_rating) FROM  rating where Video_id=".$row1['video_id'];
                                                $qry=mysqli_query($connection,$avg);
                                                $average=mysqli_fetch_array($qry);
                                                ?>
                                              
                                             <p>  COURSE: <?php print_r($row2['course_name']);?></p><br>

                                               <p>RATING: </p> <div class="rateyo" style="font-size: 15px !important; float:  center!important;" id="rating" data-rateyo-rating="<?php echo $average['AVG(Total_rating)'];?>" data-rateyo-rating="5" data-rateyo-score="3"></div>
  <br>
                                                     <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script> 

                                                 
                   <a href=" video_description.php?id=<?php echo $row1['video_id'];?> "><input type="submit" class="btn btn-primary"  value="View video"></a> 
                   <br>
                                            </div>
                                          </div>

                                                     

                                                        

                                            </div>
                                           <?php }
                                           }
                                            ?>
                                           </div>
                                            </div>
            <?php }   else
            { ?>

  
                    <div class="container">
                    <div class="row text-center" >
                     <?php
                                                 $sql="SELECT * FROM VIDEO";
                                                 $result=mysqli_query($connection,$sql);


                                                     while($row1=mysqli_fetch_array($result)){
                                                         
                                                         
                                                    $sql2="SELECT * FROM courses WHERE course_id=".$row1['course_id']."";
                                                    $result2=mysqli_query($connection,$sql2);
                                                      while ($row2=mysqli_fetch_array($result2)) { ?>
                                                        <div class="col-md-4 " style="margin-bottom: 20px;">
                                                          <div class="card h-100">
                                                            
                                                              
                                                           
                                                            <div class="card-body">
                                                              <img src="admin/image/<?php echo $row1['Thumbnail'];?>" width="200px;" class="img-thumbnail" height="100px;">
                                                              <h5 class="text-center"><?php  print_r($row1['video_title']); ?><br></h5>
                                                <?php 
                                                $avg="SELECT AVG(Total_rating) FROM  rating where Video_id=".$row1['video_id'];
                                                $qry=mysqli_query($connection,$avg);
                                                $average=mysqli_fetch_array($qry);
                                                ?>
                                              
                                             <p>  COURSE: <?php print_r($row2['course_name']);?></p><br>

                                               <p>RATING: </p> <div class="rateyo" style="font-size: 15px !important; float:  center!important;" id="rating" data-rateyo-rating="<?php echo $average['AVG(Total_rating)'];?>" data-rateyo-rating="5" data-rateyo-score="3"></div>
  <br>
                                                     <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script> 

                                                 
                   <a href=" video_description.php?id=<?php echo $row1['video_id'];?> "><input type="submit" class="btn btn-primary"  value="View video"></a> 
                   <br>
                                            </div>
                                          </div>

                                                     

                                                        

                                            </div>
                                           <?php }
                                           }
                                            ?>
                                           </div>
                                            </div>
     <?php }
include 'footer.php';?>      


   
 </div>

  
<!-- Footer -->

<!-- Footer -->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ef182329e5f694422911cce/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<script>
  $(function(){
      $(".rateyo").rateYo().on("rateyo.change",function(e,data){
        var rating=data.rating;
        $(this).parent().find('.score').text('score:'+ $(this).attr('data_rateyo-score'));
        $(this).parent().find('.result').text('rating:'+rating);
        $(this).parent().find('input[name=rating]').val(rating);
      });
  });

</script>
</body>
</html>