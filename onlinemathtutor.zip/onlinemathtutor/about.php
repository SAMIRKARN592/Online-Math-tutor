<?php
session_start();
include 'connection.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>ABOUT US</title>
  <link rel="icon"  href="https://img.icons8.com/plasticine/100/000000/about.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="css/mainstyle.css">

</head>
<body>
	<?php
 include 'navbar.php';
 ?>
<div class="container-fluid">
  <div class="container">
  <div class="row ">
    <div class="col-md-12 text-center">
          <div class="panel panel-default" style="background-color: #f5f9f4;">
            <div class="panel-body">
            <h1><i>KarnMathTutor.com</i></h1>
             <p>Learn math just by a click!</p>
             <br>
             <p>Welcome to KarnMathTutor.comh.This website is solely based on providing proper information about different topics related to mathematics and 
      along with self evaluating themselves through test. 
                  We hope you enjoy our videos as much as we enjoy offering them to you. If you have any questions or comments, please don't hesitate to contact us.
             </p>
             </div>
             </div>
 
</div>
</div>

</div>
<section class="team text-center">
     <div class="containe">
        <h1>Our Team</h1>
        <div class="card1">
            <div class="box">
                <img src="img/samir.jpg" alt="team img"  />
                <h4>Samir karn</h4>
                <h5>Manager/owner</h5>
                <p>Student of Leeds Beckett University and The british college</p>
            </div>
        </div>
        <div class="card1">
            <div class="box">
                <img src="img/suramya.jpg" class="img-thumbnail"  />
                <h4>Suramya Sharma Dahal</h4>
                <h5>Supervisor</h5>
                <p>Teacher and project supervisor of the project</p>
            </div>
        </div>
        <div class="card1">
            <div class="box">
                <img src="img/logo2.png" class="img-thumbnail"/>
                <h4>Leeds Beckett University</h4>
                <h5>Partner University</h5>
                <p>A public university in Leeds, West Yorkshire, England.</p>
            </div>
        </div>
        <div class="card1">
            <div class="box">
                <img src="img/logo1.png" class="img-thumbnail"/>
                <h4>The British College</h4>
                <h5>Partner College</h5>
                <p>The British College is an independent institution located in  Thapathali, Kathmandu</p>
            </div>
        </div>
      
     </div>
     </div>
  </section>

  </div>
<?php
include 'footer.php';?>
</div>
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ef182329e5f694422911cce/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>