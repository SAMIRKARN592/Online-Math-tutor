<?php
session_start();
include 'connection.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>HOMEPAGE</title>
  <link rel="icon" href="https://img.icons8.com/cute-clipart/64/000000/home.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
         <link rel="stylesheet" type="text/css" href="css/base.css" />
        <link rel="stylesheet" type="text/css" href="css/style2.css" />
               <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

<style>
  .social:hover {
     -webkit-transform: scale(1.1);
     -moz-transform: scale(1.1);
     -o-transform: scale(1.1);
 }
 .social {
     -webkit-transform: scale(0.8);
     /* Browser Variations: */
     
     -moz-transform: scale(0.8);
     -o-transform: scale(0.8);
     -webkit-transition-duration: 0.5s;
     -moz-transition-duration: 0.5s;
     -o-transition-duration: 0.5s;
 }

/*
    Multicoloured Hover Variations
*/
 
 #social-fb:hover {
     color: #3B5998;
 }
 #social-tw:hover {
     color: #4099FF;
 }
 #social-gp:hover {
     color: #d34836;
 }
 #social-em:hover {
     color: #f39c12;
 }



</style>
</head>
<body>
	<div class="container-fluid">
	<?php
 include 'navbar.php';
 ?>

<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="img/2.jpg" alt="First slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="img/1.jpg" alt="Second slide">
    </div>
    
     <div class="carousel-item">
      <img class="d-block w-100" src="img/4.jpg " alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


 <div class="row" style="margin-top: 20px;">
   <div class="col-md-12">
    <h3 class="text-center">COURSES AVAILBALE</h3>
     <?php
                                                 $sql="SELECT * FROM VIDEO";
                                                 $result=mysqli_query($connection,$sql);


                                                     for ($i=0; $i<3 ; $i++) { 
                                                       # code...
                                                     
                                                     ($row1=mysqli_fetch_array($result));    
                                                         
                                                    $sql2="SELECT * FROM courses WHERE course_id=".$row1['course_id']."";
                                                    $result2=mysqli_query($connection,$sql2);
                                                      while ($row2=mysqli_fetch_array($result2)) { ?>
                                                        <div class="col-md-4 " style="margin-bottom: 20px;">
                                                          <div class="card h-100">
                                                          
                                                            <div class="card-body">
                                                              <img src="admin/image/<?php echo $row1['Thumbnail'];?>"  class="img-thumbnail" style="text-align: center; height: 200px;
  width: 100%;">
                                              <h5 class="text-center"><?php  print_r($row1['video_title']); ?><br></h5>
                                                <?php 
                                                $avg="SELECT AVG(Total_rating) FROM  rating where Video_id=".$row1['video_id'];
                                                $qry=mysqli_query($connection,$avg);
                                                $average=mysqli_fetch_array($qry);
                                                ?>
                                              
                                             <p>COURSE: <?php print_r($row2['course_name']);?></p>

                                               <p>RATING: </p> <div class="rateyo" style="font-size: 15px !important; float:  center!important;" id="rating" data-rateyo-rating="<?php echo $average['AVG(Total_rating)'];?>" data-rateyo-rating="5" data-rateyo-score="3"></div>
  <br>
                                                     <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script> 

                                                 
                   <a href=" video_description.php?id=<?php echo $row1['video_id'];?> "><input type="submit" class="btn btn-primary"  value="View video"></a> 
                   <br>
                                            </div>
                                          </div>

                                                     

                                                        

                                            </div>
                                           <?php }
                                           }
                                            ?>
  
   </div>

  
 </div>
 <div class="row">
   <div class="col-md-12 text-center" ><a href="video.php" class="btn btn-success  shadow-lg p-3 mb-5  rounded" style="width: 25%;">SEE ALL VIDEOS</a></div>
 </div>
<hr>

<hr>
  
 
  <?php
   if (isset($_SESSION['userlogin'])) {
    echo " <h3 class='text-center'> RECOMMENDED VIDEO</h3>"; 

include'connection.php';
include 'recommend.php';
$videos=mysqli_query($connection,"SELECT * FROM RATING");
$matrix=array();
?>

<?php
while ($video=mysqli_fetch_array($videos)) {
  

  $sql1="SELECT username FROM USER WHERE User_id=".$video['User_id'];
        $query2=mysqli_query($connection,$sql1);
        $username=mysqli_fetch_array($query2);


  $sql2="SELECT video_title FROM VIDEO WHERE video_id=".$video['Video_id'];
  $query3=mysqli_query($connection,$sql2);
        $row3=mysqli_fetch_array($query3);
    $matrix[$username['username']][$row3['video_title']]=$video['Total_rating'];
        
}
// echo "<pre>";
// print_r($matrix);
// echo "</pre>";
 $sql1="SELECT username FROM USER WHERE User_id=".$_SESSION['id'];
        $query2=mysqli_query($connection,$sql1);
        $username=mysqli_fetch_array($query2);

?>
  
    <?php
    $recommendation=array();
    $recommendation=getRecommendation($matrix,$username['username']);
    foreach ($recommendation as $video => $rating) {
      # code...
   
      # code...
    
    ?>
    
      <div class="col-md-3 text-center ">
        <div class="card h-100">
          
            
        
          <div class="card-body">


            <?php
              $sql="SELECT * FROM VIDEO WHERE video_title='$video'";
      $qry=mysqli_query($connection,$sql);
      $row1=mysqli_fetch_array($qry);
      $stmt="SELECT course_name FROM COURSES WHERE course_id=".$row1['course_id'];
      $qry2=mysqli_query($connection,$stmt);
            $row2=mysqli_fetch_array($qry2);
?>
             <img src="admin/image/<?php echo $row1['Thumbnail'];?>" width="140px;" class="img-thumbnail" height="70px;"><br>
              <h5> <?php echo $video ; ?></h5>
                 <p> Course:<?php echo $row2['course_name'];?></p><br>
                 <h6>RATING: </h6> <div class="rateyo" style="font-size: 15px !important; float:  center!important;" id="rating" data-rateyo-rating="<?php echo $rating;?>" data-rateyo-rating="5" data-rateyo-score="3"></div><br>
                                                     <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script> 
                    <a href=" video_description.php?id=<?php echo $row1['video_id'];?> "><input type="submit" class="btn btn-primary"  value="View video"></a>
                                     <br>
                                                   </div>

          </div>
        </div>
   
    
  
    
<?php 

}
}?>

</div>
<hr>
 <div class="row" style="margin-top: 10px;">
   <div class="col-md-6 text-center">
     

   <a  class="btn btn-info shadow-lg p-3 mb-5  rounded btn-block" data-toggle="collapse" href="#collapseExample " role="button" aria-expanded="false" aria-controls="collapseExample">Click Me to play the game</a>
  
<div class="collapse" id="collapseExample">
  <div class=" card card-body text-center">
    <h1 class="text-center">Hangman</h1>
  <div class="float-right">Wrong Guesses: <span id='mistakes'>0</span> of <span id='maxWrong'></span></div>
  <div class="text-center">
    <img id='hangmanPic' src="./images/0.jpg" alt="">
    <p>Guess the Mathematical Term:</p>
    <p id="wordSpotlight">The word to be guessed goes here</p>
    <div id="keyboard"></div>
    <button class="btn btn-info" onClick="reset()">Reset</button>
  </div> 


<script src='./js/hangman.js'></script>

        </div>
        </div>
  
</div>
 <div class="col-md-6 text-center">
 
  <a  class="btn btn-secondary shadow-lg p-3 mb-5  rounded btn-block" data-toggle="collapse" href="#collapseExample1" role="button" aria-expanded="false" aria-controls="collapseExample">Click Me use the calculator</a>
     <div class="collapse" id="collapseExample1">
            <div class="phone">
            <div class="fcamera"></div>
            <div class="clens"></div>
            <div class="speaker"></div>
            <div class="screen">
            <div class="display">0</div>
            <div class="expression"></div>
            <div class="buttons clearfix">
                <div class="clear reset" onclick ="clearScreen.call(this)">CE<div class="waveButton"></div></div>
                <div class ="del reset" data-number="8" onclick="deleteANumber.call(this)">C<div class="waveButton"></div></div>
                <div class="sign reset" onclick="alternateSign.call(this)">-M<div class="waveButton"></div></div>

                <div class="sci-ops " onclick="sin.call(this)">sin<div class="waveButton"></div></div>
                <div class="sci-ops " onclick="cos.call(this)">cos<div class="waveButton"></div></div>
                <div class="sci-ops " onclick="tan.call(this)">tan<div class="waveButton"></div></div>
                <div class="sci-ops " onclick="exp.call(this)">exp<div class="waveButton"></div></div>
                <div class="sci-ops " onclick="log.call(this)">log<div class="waveButton"></div></div>
                <div class="sci-ops " onclick="log2.call(this)">log<sub>2</sub><div class="waveButton"></div></div>
                <div class="sci-ops " onclick="pow.call(this)">x<sup>2</sup><div class="waveButton"></div></div>
                <div class="sci-ops " onclick="sqrt.call(this)">&#8730;x<div class="waveButton"></div></div>
                
                <div class="number " data-number="55">7<div class="waveButton"></div></div>
                <div class="number " data-number="56">8<div class="waveButton"></div></div>
                <div class="number " data-number="57">9<div class="waveButton"></div></div>
                <div class="basic-ops " data-number="107">+<div class="waveButton"></div></div>

                <div class="number " data-number="52">4<div class="waveButton"></div></div>
                <div class="number " data-number="53">5<div class="waveButton"></div></div>
                <div class="number " data-number="54">6<div class="waveButton"></div></div>
                <div class="basic-ops " data-number="109">-<div class="waveButton"></div></div>

                <div class="number " data-number="49">1<div class="waveButton"></div></div>
                <div class="number " data-number="50">2<div class="waveButton"></div></div>
                <div class="number  " data-number="51">3<div class="waveButton"></div></div>
                <div class="basic-ops " data-number="106">*<div class="waveButton"></div></div>

                <div class="number " data-number="48">0<div class="waveButton"></div></div>
                <div class="number " data-number="110">.<div class="waveButton"></div></div>
                <div class="equals " data-number="13" onclick="equals.call(this)">&#61;<div class="waveButton"></div></div>
                <div class="basic-ops " data-number="111">/<div class="waveButton"></div></div>
            </div>
         </div>
        <div class="lock_btn"></div>
        <div class="volume_btn"></div>
        <div class="task_bar"></div>

        <script type="text/javascript" src="js/calculator.js"></script>

        
  </div>

   </div>
 </div>
   </div>

<!-- Footer -->
<?php
include 'footer.php';?>
<!-- Footer -->

</div>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ef182329e5f694422911cce/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<script>
  $(function(){
      $(".rateyo").rateYo().on("rateyo.change",function(e,data){
        var rating=data.rating;
        $(this).parent().find('.score').text('score:'+ $(this).attr('data_rateyo-score'));
        $(this).parent().find('.result').text('rating:'+rating);
        $(this).parent().find('input[name=rating]').val(rating);
      });
  });

</script>
</body>
</html>