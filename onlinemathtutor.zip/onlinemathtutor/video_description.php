<?php
session_start();

include 'connection.php';
 if (!isset($_SESSION['userlogin'])) {
        header('Location: login.php');
    }


?>
<!DOCTYPE html>
<html>
<head>
	<title>VIDEO TUTORIALS</title>
  <link rel="icon" href="https://img.icons8.com/color/48/000000/movies-folder.png">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

</head>
<body>
	<?php
 include 'navbar.php';
 ?>

<?php


if (isset($_GET['id'])) {
                        $id=$_GET['id'];
                        $_SESSION['abd']=$id;
                          $quer="SELECT * from VIDEO where video_id=".$_GET['id']."";
                          $result =mysqli_query($connection,$quer);
                          $row2=mysqli_fetch_array($result);
                         
                                  # code...
                                
                        $query= "INSERT INTO enrolled_course(user_id,course_id) VALUES (".$_SESSION['id'].",".$row2['course_id'].")";
                        $res=mysqli_query($connection,$query);
                          
                              // echo '<script>window.location.href="video_description.php?id=".$vid_id."</script>'; 
                        // echo"<script>document.location='video_description.php?id=$id ';</script>";

                        
                        } 


                                                        


?>
 <div class=" container-fluid">
   <?php
          
 
          $sql="SELECT * FROM video WHERE video_id=".$_GET['id']."";
              $res=mysqli_query($connection,$sql);
              while ($row=mysqli_fetch_array($res)) {?>
               <h2 class="text-center"> <?php print_r($row['video_title']);?></h2>
               
    <div class="row">
      <div class="col-md-12 text-center">
         <video width="720" height="400" controls="control" tabindex="0">
        
        <source src="admin/videos/<?php print_r($row['video_title'])  ?>" type="video/mp4">
               <source src="admin/videos/<?php print_r($row['video_title'])  ?>" type="video/ogg">

               <source src="admin/videos/<?php print_r($row['video_title'])  ?>" type="video/webm">
        Your browser does not support the video tag.
        </video> 
      
      </div>
    </div>
   
      <div class="row">
        <div class="col-md-12 text-center my-10" >
         <a role="button" style="width: 40%;" href="quiz.php?id=<?php echo $row['video_id'];?> "class="btn btn-info  shadow-lg p-3 mb-5  rounded btn-lg ">CLICK ME FOR THE QUIZ</a>
          <?php } ?>

        </div>
      </div>
<br><br>
<div class="row" style=" max-width: 300px;">
  <div class="col-md-12">
   
    <form action="" method="POST">
      
      <div class="rateyo" id="rating" data-rateyo-rating="4" data-rateyo-rating="5" data-rateyo-score="3"></div>
      


      <span class="result"></span>
      <input type="hidden" name="rating"><br>
        <input type="submit" name="addrating" class=" btn btn-info" value="Rate the video">
    </form>
    
   <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script> 


  </div>
</div>

<hr>





<div class="row">
  <div class="col-md-12">
       <form method="POST" id="comment_form">
        <h4>VIDEO REVIEWS</h4>
    
    <div class="form-group">
     <textarea name="comment_content" id="comment_content" style=" border:0px;
   border-bottom:2px solid #eee;" class="form-control" placeholder="Enter Comment" rows="1" required="required"></textarea>
    </div>
    <div class="form-group">
     <input type="hidden" name="comment_id" id="comment_id" value="0" />
     <input type="submit" name="reviews" id="submit" class="btn btn-info" value=" ADD Reviews" />
    </div>
   </form>
   

   
  </div>
  </div>
</div>
<?php
if (isset($_POST['reviews'])) {
      $comment_content=$_POST['comment_content'];
      $sql4= "INSERT INTO reviews(Description,user_id,video_id) VALUES('$comment_content',".$_SESSION['id'].",".$_SESSION['abd'].")";
      $qry=mysqli_query($connection,$sql4);
      echo "<script>alert('Thank you for reviewing the video. Your review has been added')</script>";
}?>
<hr>

<div class="row">
  <div class="col-md-12" style="margin-left: 20PX;">
    <?php
    $stmt="SELECT * FROM REVIEWS WHERE video_id=".$_SESSION['abd'];
    $qry1=mysqli_query($connection,$stmt);

    while($row1=mysqli_fetch_array($qry1))
    {
      if($row1['user_id']==$_SESSION['id'])
      {?>
        

       
        <span style="font-size: 12px;  color: #97a6a5;"> By <?php echo $_SESSION['username']?></span><br>
       <span style="font-size: 15px; "> <?php 
       echo $row1['Description']; ?><br></span><a href="deletereviews.php?id='<?php echo $row1["Reviews_id"];?>'"><button type="submit" class="btn btn-link  btn-sm" style="  font-size:10px; color: #ff1300;"  ><i class="fa fa-trash" aria-hidden="true"></i>
</button></a>

  <a class="btn btn-link" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
    Add Reply
  </a>
  <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseExample2" aria-expanded="false" aria-controls="collapseExample">
    View replies
  </button>

<div class="collapse" id="collapseExample">
  <div class="card card-body">
   <form method="POST" id="comment_form">
      
    
    <div class="form-group">
     <textarea name="replytext" id="comment_content" style=" border:0px;
   border-bottom:2px solid #eee;" class="form-control" placeholder="Enter your reply" rows="1" required="required"></textarea>
    </div>
    <div class="form-group">
     <input type="hidden" name="comment_id" id="comment_id" value="0" />
     <input type="submit" name="reply" id="submit" class="btn btn-info" value=" Reply" />
    </div>
   </form>
    <?php if (isset($_POST['reply'])) {
      $replytext=$_POST['replytext'];
      $sql3="INSERT INTO reply(replytext,User_id,Reviews_id) VALUES('$replytext',".$_SESSION['id'].",".$row1['Reviews_id'].")";
      $add=mysqli_query($connection,$sql3);
      echo "<script>alert('Thank you for replying')</script>";


    }
    ?>
  </div>
</div>
<div class="collapse" id="collapseExample2">
  <div class="card card-body">
<?php
    $sql4="SELECT * FROM REPLY WHERE Reviews_id=".$row1['Reviews_id'];
    $query1=mysqli_query($connection,$sql4);
    while ($rep=mysqli_fetch_array($query1)) {
                $stmnt4="SELECT * FROM USER WHERE User_id =".$rep['User_id'];
          $qrt4=mysqli_query($connection,$stmnt4);
           $row4=mysqli_fetch_array($qrt4);
          ?>
       <span style="font-size: 12px;  color: #97a6a5;"> By <?php echo $row4['username']?></span><br>
        <?php 
       echo $rep['replytext']; ?><br></span>

              <?php if ($rep['User_id']==$_SESSION['id']) {?>

       <a href="deletereply.php?id='<?php echo $rep["reply_id"];?>'"><button type="submit" class="btn btn-link  btn-sm" style="  font-size:10px; color: #ff1300;"  ><i class="fa fa-trash" aria-hidden="true"></i>
</button></a>

<?php } ?>
<hr>
 <?php   }
    ?>
  </div>
</div>

   

     <?php }
       else {
          $stmnt="SELECT * FROM USER WHERE User_id =".$row1['user_id'];
          $qrt=mysqli_query($connection,$stmnt);
          while ($row3=mysqli_fetch_array($qrt)) {?>
                   <span style="font-size: 12px;  color: #97a6a5;"> By <?php echo $row3['username'];?></span><br>
 
         <?php }

          ?>
            <span style="font-size: 15px; ">

        <?php echo $row1['Description']; ?></span>
        <br>  <a class="btn btn-link" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
    Add Reply
  </a>
  <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseExample2" aria-expanded="false"   aria-controls="collapseExample">
    View replies
  </button>

<div class="collapse" id="collapseExample">
  <div class="card card-body">
   <form method="POST" id="comment_form">
      
    
    <div class="form-group">
     <textarea name="replytext" id="comment_content" style=" border:0px;
   border-bottom:2px solid #eee;" class="form-control" placeholder="Enter your reply" rows="1" required="required"></textarea>
    </div>
    <div class="form-group">
     <input type="hidden" name="comment_id" id="comment_id" value="0" />
     <input type="submit" name="reply" id="submit" class="btn btn-info" value=" Reply" />
    </div>
   </form>
    <?php if (isset($_POST['reply'])) {
      $replytext=$_POST['replytext'];
      $sql3="INSERT INTO reply(replytext,User_id,Reviews_id) VALUES('$replytext',".$_SESSION['id'].",".$row1['Reviews_id'].")";
      $add=mysqli_query($connection,$sql3);
      echo "<script>alert('Thank you for replying')</script>";


    }
    ?>
  </div>
</div>
<div class="collapse" id="collapseExample2">
  <div class="card card-body">
    <?php
    $sql4="SELECT * FROM REPLY WHERE Reviews_id=".$row1['Reviews_id'];
    $query1=mysqli_query($connection,$sql4);
    while ($rep=mysqli_fetch_array($query1)) {
                $stmnt4="SELECT * FROM USER WHERE User_id =".$rep['User_id'];
          $qrt4=mysqli_query($connection,$stmnt4);
           $row4=mysqli_fetch_array($qrt4);
          ?>
          
       <span style="font-size: 12px;  color: #97a6a5;"> By <?php echo $row4['username']?></span><br>
       <span style="font-size: 15px; "> <?php 
       echo $rep['replytext']; ?><br></span>
      
       <?php if ($rep['User_id']==$_SESSION['id']) {?>
       
        <a href="deletereply.php?id='<?php echo $rep["reply_id"];?>'"><button type="submit" class="btn btn-link  btn-sm" style="  font-size:10px; color: #ff1300;"  ><i class="fa fa-trash" aria-hidden="true"></i>
</button></a>

     <?php } ?>
       

 <?php   }
    ?>
        <hr>
   <?php  }
    }
    ?>
  </div>
</div>





<?php
include 'footer.php';?>




</div>
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ef182329e5f694422911cce/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<script>
  $(function(){
      $(".rateyo").rateYo().on("rateyo.change",function(e,data){
        var rating=data.rating;
        $(this).parent().find('.score').text('score:'+ $(this).attr('data_rateyo-score'));
        $(this).parent().find('.result').text('rating:'+rating);
        $(this).parent().find('input[name=rating]').val(rating);
      });
  });

</script>
   <?php
if (isset($_POST['addrating'])) {
  # code...

  $rating=$_POST['rating'];
  $first="SELECT * FROM RATING WHERE User_id=".$_SESSION['id']." AND Video_id=".$_SESSION['abd'];
  $exe=mysqli_query($connection,$first);
  $count=mysqli_num_rows($exe);

  if ($count>0) {
    $sql="UPDATE rating SET Total_rating = $rating  WHERE User_id=".$_SESSION['id']." AND Video_id = ".$_SESSION['abd'];

  $run=mysqli_query($connection,$sql);
  echo "<script>alert('Your rating has been updated');</script>";
  } 

else{
  $sql=" INSERT INTO RATING (Total_rating,User_id,Video_id) VALUES ('$rating',".$_SESSION['id'].",".$_SESSION['abd'].")";
  $run=mysqli_query($connection,$sql);
  echo "<script>alert('Thank you for your rating to the videos');</script>";

}

}
?>
</body>
</html>


