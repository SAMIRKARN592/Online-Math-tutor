<?php



Include 'connection.php';
	if (isset($_POST['signup-button'])) {
		# code...
	
	$name = $_POST['name'];
	
	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	   
		$count=0;
		$count1=0;
		$sql=mysqli_query($connection,"SELECT * FROM USER WHERE username='$username'");
			$count=mysqli_num_rows($sql);

		$sql2=mysqli_query($connection,"SELECT * FROM USER WHERE email='$email'");
		$count1=mysqli_num_rows($sql2);
		
			if ($count>0) {
				?>
				<script type="text/javascript">
					alert("Username already exists!! Select another one");
				</script>
		<?php
			header("Location: signup.php?error=Username already exists");
			}
			elseif ($count1>0) {
				?>
					<script type="text/javascript">
					alert("email already exists!! Select another one");
					</script>
					<?php
					  header("Location: signup.php?error=email already exists");
			}
			else{
	  $password=md5($password);
		$query = "INSERT INTO user(Name,email,username ,password,Role,Status) VALUES  ('$name','$email','$username','$password',0,1);";
		
	 	$uplo=mysqli_query($connection, $query);
	 		?>
				<script type="text/javascript">
					alert("Thank you for registering to the site");
				</script>

		<?php
		header('Location:login.php');
}
	}
	
 //   if(!preg_match('/^(?=.*\d)(?=.*[@#\-_$%^&+=§!\?])(?=.*[a-z])(?=.*[A-Z])[0-9A-Za-z@#\-_$%^&+=§!\?]{8,20}$/',$password)) {
	
	// 	  // echo "<script>alert ('')</script>";
		

 //   		$error =1;
	// header("Location: signup.php?error=Password should atleast have a capital letter,number and special character");
	// exit();
	// # code...


	// }
 // if(!preg_match("/^[a-zA-Z'-]+$/",$name)) 
	// { 
	// 	$valid=true;
	// header("Location: signup.php?error=name should not have any special character or number");
	// exit();
	// 	} 
 


	// if ($valid==false) {
	// 	# code...
	
	// $password=md5($password);
	// $query = "INSERT INTO user(Name,email,username ,password,Role,Status) VALUES ( '$name','$email','$username','$password',0,1);";
		
	// 	$uplo=mysqli_query($connection, $query);
	// 	if (isset($uplo)) {
	// 		  echo "<script>alert ('Thank you for registering to madmathtutor.com')</script>";
	// 		header('Location:login.php');
	// 	}
	// 	else{
	// 	}
	// }

	 
	?>