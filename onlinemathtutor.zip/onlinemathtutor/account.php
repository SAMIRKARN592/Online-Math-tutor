<?php
session_start();
include 'connection.php';
require 'phpmailer/PHPMailerAutoload.php';

if (!isset($_SESSION['userlogin'])) {
        header('Location: login.php');
    }

?>

 
    <?php
    if (isset($_POST['submit'])) {
      if(!empty($_POST['quizcheck']))
      {
        $count = count($_POST['quizcheck']);
        // echo $count." options selected";
        $result=0;
                $selected=$_POST['quizcheck'];

         $stmnt="SELECT * FROM QUESTIONS WHERE video_id=".$_SESSION['abd'];
         $qry=mysqli_query($connection,$stmnt);
         while($row1=mysqli_fetch_array($qry)){   
        
                
        $sql=" SELECT * FROM ANSWER WHERE correct=1 AND Questions_id=".$row1['Questions_id'];
        $query=mysqli_query($connection,$sql);
        while($rows= mysqli_fetch_array($query)){
            $_SESSION['bcd']=$rows['Questions_id'];
            $checked = $rows['ans_id'] == $selected[$rows['Questions_id']];
            if ($checked) {
              $result++;
            }


        }
       
        
      }
          echo "<script>alert('Congratulation!!! You got '+$result+' questions right out of '+$count+' questions')</script> ";
      $stmt="SELECT * FROM QUESTIONS WHERE Questions_id=".$_SESSION['bcd'];
      $res=mysqli_query($connection,$stmt);
      while($row3=mysqli_fetch_array($res)){
         
              $_SESSION['abe']=$row3['video_id'];
            

      }
      # code...
  

      $sql5="INSERT INTO TEST(test_score, user_id,video_id) VALUES('$result',".$_SESSION['id'].",".$_SESSION['abe'].")";
      $query1= mysqli_query($connection,$sql5);

    }
  }?>

<!DOCTYPE html>
<html>
<head>
  <title>USER INFO PAGE</title>
  <link rel="icon" href="https://img.icons8.com/bubbles/50/000000/edit-user.png">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<style>
  .social:hover {
     -webkit-transform: scale(1.1);
     -moz-transform: scale(1.1);
     -o-transform: scale(1.1);
 }
 .social {
     -webkit-transform: scale(0.8);
     /* Browser Variations: */
     
     -moz-transform: scale(0.8);
     -o-transform: scale(0.8);
     -webkit-transition-duration: 0.5s;
     -moz-transition-duration: 0.5s;
     -o-transition-duration: 0.5s;
 }

/*
    Multicoloured Hover Variations
*/
 
 #social-fb:hover {
     color: #3B5998;
 }
 #social-tw:hover {
     color: #4099FF;
 }
 #social-gp:hover {
     color: #d34836;
 }
 #social-em:hover {
     color: #f39c12;
 }
</style>
</head>
<body>
  <div class="container-fluid">
  <?php
 include 'navbar.php';
 ?>

 <div class="row">
   <div class="col-md-8"><div class="card">
  <div class="card-header">
    <h4 class="text-center">TEST SCORES</h4>
  </div>
  <div class="card-body">
    <h5 class="card-title text-center">CHECK ALL YOUR TEST SCORES</h5>
    <div class=" table-full-width table-responsive">
                                  <table class="table table-hover table-striped">
                                        <thead>
                                            <th>Test_id</th>
                                            <th>Tutorial name</th>
                                            <th>Test Score</th>
                                            <th>Test Date</th>
                                        </thead>
                                        <tbody>
                                            <tr>

                                                <?php 
                                                  $sql3="SELECT  * FROM TEST WHERE user_id=".$_SESSION['id'];
                                                  $result1 = mysqli_query($connection,$sql3);
                                                while($row2=mysqli_fetch_array($result1)){
                                                    $sql2="SELECT * FROM VIDEO WHERE video_id=".$row2['video_id'];
                                                    $result2=mysqli_query($connection,$sql2);
                                                    while ($row4=mysqli_fetch_array($result2)) {
                                                      # code...
                                                    
                                                    ?>

                                                <td><?php print_r($row2['Test_id']); ?></td>
                                                         <td><?php print_r($row4['video_title']); ?></td>
<!--  -->                                                <td><?php print_r($row2['test_score']); ?></td>
                                                     <td><?php print_r($row2['TEST_DATE']); ?></td>
                              
                                            </tr>
                                           <?php }
                                           } ?>
                                        </tbody>
                                    </table>  
                                </div>
                            </div>
  </div>
  <br>
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header text-center" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">CHECK YOUR RATING</div>
                                <div class="collapse" id="collapseExample">
                                <div class="card-body"   >
                                    <table class="table table-hover table-striped">
                                                    <thead>
                                                        <th>Video Name</th>
                                                        <th>Rating</th>
                                                    </thead>
                                                    <tbody>
                                 <?php 
                                            $sel="SELECT * FROM USER WHERE User_id=".$_SESSION['id'];
                                            $query=mysqli_query($connection,$sel);
                                            while ($row1=mysqli_fetch_array($query)) {
                                                
                                            

                                                $avg="SELECT * FROM  rating where User_id=".$row1['User_id'];
                                                $qry=mysqli_query($connection,$avg);
                                                while ( $average=mysqli_fetch_array($qry)) {
                                                    # code...
                                                
                                                $stmt2="SELECT video_title FROM VIDEO WHERE video_id=".$average['Video_id'];
                                                $qry2=mysqli_query($connection,$stmt2);
                                                $ro5=mysqli_fetch_array($qry2);
                                                
                                                ?>
                                                   
                                                    <tr>
                                                        <td><?php echo  $ro5['video_title'];?></td>
                                                        <td><?php echo $average['Total_rating'];?> out of 5
                                                      </td>
                                                    </tr>
                                                                                       
                                      
                                      <?php
                                  }
                              }
                                      ?>
                                        </tbody>
                                    </table>
                                </div>
                              </div>
      </div>
    </div>
        

  </div>
</div>
   <div class="col-md-4"><div class="card">
  <div class="card-header text-center">
    YOUR INFORMATION
  </div>
  <div class="card-body">
    <h4>                  
    <?php
    $sql6="SELECT * FROM USER WHERE user_id=".$_SESSION['id'];
    $run=mysqli_query($connection,$sql6);
    while($roq=mysqli_fetch_array($run)) { ?>   
                            <?php echo $roq['Name'];?></h4>
                       
                        <p>
                            <i class="glyphicon glyphicon-envelope"></i> &nbsp; &nbsp; &nbsp;<?php echo $roq['email'];?>
                            <br />
                            <?php $_SESSION['email']=  $roq['email'];?>
                           
                            <br />
                            <i class="glyphicon glyphicon-user"></i>  &nbsp; &nbsp; &nbsp;<?php echo $roq['username']?></p>
                        <!-- Split button -->
                        <?php } ?>
</div><br>
<br>
<br>
<div class="card">
  <div class="card-header text-center">
    Change password
  </div>
  <?php

  ?>
  <div class="card-body">
    
    <form name="chngpwd" action="" method="post" onSubmit="return valid();">
    <table align="center">
    <tr height="50">
    <td>Old Password :</td>
    <td><input type="password" name="opwd" id="opwd"></td>
    </tr>
    <tr height="50">
    <td>New Passowrd :</td>
    <td><input type="password" name="npwd" id="npwd"></td>
    </tr>
    <tr height="50">
    <td>Confirm Password :</td>
    <td><input type="password" name="cpwd" id="cpwd"></td>
    </tr>
    <tr>
    
    <td><input type="submit" class="btn btn-success text-center" name="Submit" value="Change Passowrd" /></td>
   

    </tr>
    </table>
    </form>
  </div>
</div></div>
  
 </div> 

</div>




<br>
<br>


<!-- Footer -->
<?php
include 'footer.php';?>
</div>
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ef182329e5f694422911cce/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>
<script type="text/javascript">
function valid()
{
if(document.chngpwd.opwd.value=="")
{
alert("Old Password Filed is Empty !!");
document.chngpwd.opwd.focus();
return false;
}
else if(document.chngpwd.npwd.value=="")
{
alert("New Password Filed is Empty !!");
document.chngpwd.npwd.focus();
return false;
}
else if(document.chngpwd.cpwd.value=="")
{
alert("Confirm Password Filed is Empty !!");
document.chngpwd.cpwd.focus();
return false;
}
else if(document.chngpwd.npwd.value!= document.chngpwd.cpwd.value)
{
alert("Password and Confirm Password Field do not match  !!");
document.chngpwd.cpwd.focus();
return false;
}
return true;
}
</script>
<?php
;
if(isset($_POST['Submit']))
{
 $oldpass=md5($_POST['opwd']);
 
 $newpassword=md5($_POST['npwd']);
$stmt1="SELECT password from USER WHERE password='$oldpass' and User_id=".$_SESSION['id'];
$sql2=mysqli_query($connection,$stmt1);
$num=mysqli_fetch_array($sql2);

if($num>0)
{
 $con=mysqli_query($connection,"UPDATE USER SET password='$newpassword' WHERE User_id=" .$_SESSION['id']);
  echo "<script>alert('Password updated successfully')</script>";
   $mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = 2;                                       // Enable verbose debug output
    $mail->isSMTP();                                            // Set mailer to use SMTP
    $mail->Host       = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'karnmathtutor@gmail.com';                     // SMTP username
    $mail->Password   = 'Rimas@592';                               // SMTP password
    $mail->SMTPSecure = 'ssl';                                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port       = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('karnmathtutor@gmail.com', 'karnmathtutor');
    $mail->addAddress($_SESSION['email'], $_SESSION['username']);     // Add a recipient
    //$mail->addAddress('ellen@example.com');               // Name is optional
    $mail->addReplyTo('info@example.com', 'Information');
    $mail->addCC('cc@example.com');
    $mail->addBCC('bcc@example.com');

    // Attachments
  //  $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Welcome to karnmathtutor.com';
    $mail->Body    = 'Your password has been updated and has been set to<br>password:'.$_POST['npwd'];
    $mail->AltBody = 'keep the username and password safe for further use and avoid sharing it';

    if ($mail->send()) {
      
      echo "<script>alert(' YOUR UPDATED PASSWORD HAS BEEN SENT TO YOU');window.location='login.php'; </script>";
      

    }
   
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";

}
}


else
{
echo "<script>alert('Password updated successfully')</script>";

}
}
?>