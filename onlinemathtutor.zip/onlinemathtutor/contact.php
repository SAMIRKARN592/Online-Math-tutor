<?php
session_start();
require 'phpmailer/PHPMailerAutoload.php';
    
include 'connection.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>CONTACT US</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<style >
  .contact-form{
    background: #fff !important;
    margin-top: 10% !important;
    margin-bottom: 5% !important;
    width: 70% !important;
}
.contact-form .form-control{
    border-radius:1rem !important;
}
.contact-image{
    text-align: center !important;
}
.contact-image img{
    border-radius: 6rem !important;
    width: 11% !important;
    margin-top: -3% !important;
    transform: rotate(29deg) !important;
}
.contact-form form{
    padding: 14% !important;
}
.contact-form form .row{
    margin-bottom: -7% !important;
}
.contact-form h3{
    margin-bottom: 8% !important;
    margin-top: -10% !important;
    text-align: center !important;
    color: #72f08b !important;
}
.contact-form .btnContact {
    width: 50% !important;
    border: none !important;
    border-radius: 1rem !important;
    padding: 1.5% !important;
    background: #72f08b!important;
    font-weight: 600 !important;
    color: #fff;
    cursor: pointer !important;
}
.btnContactSubmit
{
    width: 50% !important;
    border-radius: 1rem !important;
    padding: 1.5% !important;
    color: #fff !important;
    background-color: #0062cc !important;
    border: none !important;
    cursor: pointer !important;
}
</style>
</head>
<body>
	<?php
 include 'navbar.php';
 ?>

<div class="container contact-form">
            <div class="contact-image">
                <img src="https://image.ibb.co/kUagtU/rocket_contact.png" alt="rocket_contact" />
            </div>
            <form method="post">
                <h3>Drop Us a Message</h3>
               <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <input type="text" name="txtName" class="form-control" placeholder="Your Name *" value=""  required="required" />
                        </div>
                        <div class="form-group">
                            <input type="text" name="txtEmail" class="form-control" placeholder="Your Email *" required="required" value="" />
                        </div>
                        <div class="form-group">
                            <input type="text" name="txtPhone" required="required" class="form-control" placeholder="Your Phone Number *" value="" />
                        </div>
                        <div class="form-group">
                            <input type="submit" name="btnSubmit" class="btnContact" value="Send Message" />
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <textarea name="txtMsg" class="form-control" required="required" placeholder="Your Message *" style="width: 100%; height: 150px;"></textarea>
                        </div>
                    </div>
                </div>
            </form>
</div>


<?php
        if(isset($_POST['btnSubmit'])){
        $fnam=$_POST['txtName'];
        $email1=$_POST['txtEmail'] ;
        $mesg=$_POST['txtMsg'];
        $phone=$_POST['txtPhone'];
         $mail = new PHPMailer(true);

try {

  
    //Server settings
    $mail->SMTPDebug = 2;                                       // Enable verbose debug output
    $mail->isSMTP();                                            // Set mailer to use SMTP
    $mail->Host       = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'karnmathtutor@gmail.com';                     // SMTP username
    $mail->Password   = 'Rimas@592';                               // SMTP password
    $mail->SMTPSecure = 'ssl';                                  // Enable TLS encryption, `ssl` also accepted
    $mail->Port       = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('karnmathtutor@gmail.com', 'KarnMathTutor');
    $mail->addAddress('karnsamir12@gmail.com', 'Admin');     // Add a recipient
    //$mail->addAddress('ellen@example.com');               // Name is optional
    $mail->addReplyTo('info@example.com', 'Information');
    $mail->addCC('cc@example.com');
    $mail->addBCC('bcc@example.com');

    // Attachments
  //  $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    //$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    // Content
    $mail->isHTML(true); 
        $mail->addStringAttachment($pdf->Output("S",'ReviewDetails.pdf'), 'ReviewDetails.pdf', $encoding = 'base64', $type = 'application/pdf');                                 // Set email format to HTML
    $mail->Subject = 'please provide proper feedback email';
    $mail->Body    = ' Dear Admin,The user '.$fnam.' had some issue with the website. please Review his problem.<br> Here are the details of the user<br><<p> Email: '.$email1.'</p><br><p>Phone: '.$phone.'</p><br><p>Message:'.$mesg.'</p>';
    $mail->AltBody = 'Hope you have an amazing day';

if ($mail->send()) {
      
      echo "<script>alert('Thank you.we will get back to you as soon as possible.');window.location='contact.php'; </script>";
      

    }   
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
  }    
      //if check doesn't match....
      else{
       
      }
   ?>
 <!-- Footer -->
<?php
include 'footer.php';?>
<!-- Footer -->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ef182329e5f694422911cce/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>
</html>